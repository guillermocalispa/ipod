const APP_CACHE = 'ipod-app-v1';
const MUSIC_CACHE = 'ipod-music-v1';

// Assets to pre-cache on install
const APP_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json'
];

// Install: pre-cache app shell
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(APP_CACHE).then((cache) => cache.addAll(APP_ASSETS))
  );
  self.skipWaiting();
});

// Activate: clean old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((k) => k !== APP_CACHE && k !== MUSIC_CACHE)
          .map((k) => caches.delete(k))
      )
    )
  );
  self.clients.claim();
});

// Fetch strategy:
// - blob: URLs (local music) → always network (object URLs can't be cached)
// - audio files → cache-first with MUSIC_CACHE
// - everything else → stale-while-revalidate with APP_CACHE
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Skip non-GET and chrome-extension requests
  if (request.method !== 'GET') return;
  if (url.protocol === 'chrome-extension:') return;
  if (url.protocol === 'blob:') return;

  // Audio files → cache-first (MUSIC_CACHE)
  const isAudio =
    /\.(mp3|m4a|wav|ogg|flac|aac|wma)$/i.test(url.pathname) ||
    request.destination === 'audio';

  if (isAudio) {
    event.respondWith(
      caches.open(MUSIC_CACHE).then(async (cache) => {
        const cached = await cache.match(request);
        if (cached) return cached;
        const response = await fetch(request);
        if (response.ok) cache.put(request, response.clone());
        return response;
      })
    );
    return;
  }

  // App shell / assets → stale-while-revalidate
  event.respondWith(
    caches.open(APP_CACHE).then(async (cache) => {
      const cached = await cache.match(request);
      const fetchPromise = fetch(request)
        .then((response) => {
          if (response.ok) cache.put(request, response.clone());
          return response;
        })
        .catch(() => cached);

      return cached || fetchPromise;
    })
  );
});

// Message: clear music cache on demand
self.addEventListener('message', (event) => {
  if (event.data?.type === 'CLEAR_MUSIC_CACHE') {
    caches.delete(MUSIC_CACHE).then(() => {
      event.source?.postMessage({ type: 'MUSIC_CACHE_CLEARED' });
    });
  }
});
