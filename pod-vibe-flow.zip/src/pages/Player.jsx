import React, { useState, useRef, useCallback, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import useAudioEngine from '../components/ipod/useAudioEngine';
import Visualizer from '../components/ipod/Visualizer';
import Equalizer from '../components/ipod/Equalizer';
import NowPlaying from '../components/ipod/NowPlaying';
import IpodMenu from '../components/ipod/IpodMenu';
import PlaylistView from '../components/ipod/PlaylistView';
import ClickWheel from '../components/ipod/ClickWheel';
import ProgressBar from '../components/ipod/ProgressBar';
import ClosingOverlay from '../components/ipod/ClosingOverlay';
import MusicExplorer from '../components/ipod/MusicExplorer';

const SKINS = [
  { name: 'black', icon: '◐' },
  { name: 'white', icon: '◑' },
  { name: 'red', icon: '◒' },
  { name: 'green', icon: '◓' },
  { name: 'purple', icon: '◔' }
];

const ACCENT_COLORS = {
  black: '#3b82f6',
  white: '#0066cc',
  red: '#ff4444',
  green: '#22c55e',
  purple: '#a855f7'
};

export default function Player() {
  const [currentView, setCurrentView] = useState(0); // 0=viz, 1=eq, 2=tags, 3=menu, 4=playlist
  const [skinIdx, setSkinIdx] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showClosing, setShowClosing] = useState(false);
  const [showExplorer, setShowExplorer] = useState(false);
  const [saveStatus, setSaveStatus] = useState('Guardar');
  const [loadStatus, setLoadStatus] = useState('Cargar');
  const [clock, setClock] = useState('12:00');

  const touchStartRef = useRef(0);
  const ipodRef = useRef(null);

  const queryClient = useQueryClient();

  const engine = useAudioEngine();

  const skin = SKINS[skinIdx].name;
  const accentColor = ACCENT_COLORS[skin];
  const isWhiteSkin = skin === 'white';

  // Portrait lock on mount (compatible with WebView/WebInto)
  useEffect(() => {
    const lockPortrait = async () => {
      try {
        if (screen.orientation?.lock) {
          await screen.orientation.lock('portrait');
        }
      } catch (_) {}
    };
    lockPortrait();
  }, []);

  // Clock
  useEffect(() => {
    const update = () => {
      const d = new Date();
      setClock(d.getHours().toString().padStart(2, '0') + ':' + d.getMinutes().toString().padStart(2, '0'));
    };
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, []);

  // Load saved playlists from entity
  const { data: savedPlaylists } = useQuery({
    queryKey: ['playlists'],
    queryFn: () => base44.entities.Playlist.list('-created_date', 50),
    initialData: []
  });

  const saveMutation = useMutation({
    mutationFn: (data) => base44.entities.Playlist.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['playlists'] });
      setSaveStatus('✓ Guardado');
      setTimeout(() => setSaveStatus('Guardar'), 2000);
    }
  });

  // View management
  const showView = useCallback((n) => setCurrentView(n), []);

  const nextView = useCallback(() => {
    if (currentView >= 3) setCurrentView(0);
    else setCurrentView(prev => (prev + 1) % 4);
  }, [currentView]);

  // Swipe handling
  const handleTouchStart = (e) => { touchStartRef.current = e.changedTouches[0].screenX; };
  const handleTouchEnd = (e) => {
    const diff = touchStartRef.current - e.changedTouches[0].screenX;
    if (Math.abs(diff) > 50) {
      if (diff > 0) nextView();
      else {
        const prev = currentView - 1;
        setCurrentView(prev < 0 ? 3 : prev);
      }
    }
  };
  const handleMouseDown = (e) => { touchStartRef.current = e.screenX; };
  const handleMouseUp = (e) => {
    const diff = touchStartRef.current - e.screenX;
    if (Math.abs(diff) > 50) {
      if (diff > 0) nextView();
      else {
        const prev = currentView - 1;
        setCurrentView(prev < 0 ? 3 : prev);
      }
    }
  };

  // File handling via MusicExplorer
  const handleExplorerImport = useCallback((parsedTracks, replace) => {
    engine.addParsedTracks(parsedTracks, replace);
    setCurrentView(2);
  }, [engine]);

  const triggerImport = () => setShowExplorer(true);
  const triggerAddMore = () => setShowExplorer(true);

  // Save playlist to entity
  const handleSavePlaylist = () => {
    if (engine.tracks.length === 0) {
      setSaveStatus('Vacío');
      setTimeout(() => setSaveStatus('Guardar'), 2000);
      return;
    }
    const data = {
      name: `Playlist ${new Date().toLocaleDateString()}`,
      tracks: engine.tracks.map(t => ({
        name: t.name,
        artist: t.artist,
        duration: t.duration,
        track_id: t.track_id
      })),
      track_count: engine.tracks.length
    };
    saveMutation.mutate(data);
  };

  // Load playlist (shows saved playlists info)
  const handleLoadPlaylist = () => {
    if (savedPlaylists.length === 0) {
      setLoadStatus('Vacío');
      setTimeout(() => setLoadStatus('Cargar'), 2000);
      return;
    }
    const latest = savedPlaylists[0];
    setLoadStatus(`${latest.track_count || 0} pistas`);
    setTimeout(() => setLoadStatus('Cargar'), 3000);
  };

  // Track selection from playlist
  const handleSelectTrack = (idx) => {
    engine.loadTrack(idx);
    setCurrentView(2);
  };

  // Fullscreen
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen?.();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.();
      setIsFullscreen(false);
    }
  };

  useEffect(() => {
    const handler = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', handler);
    return () => document.removeEventListener('fullscreenchange', handler);
  }, []);

  // Close/exit handler
  const handleClose = () => {
    engine.pauseAudio();
    setShowClosing(true);
  };

  const handleCloseConfirm = () => {
    setShowClosing(false);
    if (document.fullscreenElement) {
      document.exitFullscreen?.();
    }
    setIsFullscreen(false);
  };

  const handleCloseCancel = () => {
    setShowClosing(false);
  };

  // Toggle play — if no tracks go to menu
  const handleTogglePlay = () => {
    if (engine.tracks.length === 0) {
      setCurrentView(3);
      return;
    }
    engine.togglePlay();
  };

  const currentTrackData = engine.tracks[engine.currentTrack] || null;

  return (
    <div className={`ipod-skin-${skin} min-h-screen flex justify-center`} style={{ background: '#000' }}>
      {showExplorer && (
        <MusicExplorer
          accentColor={accentColor}
          onImport={handleExplorerImport}
          onClose={() => setShowExplorer(false)}
        />
      )}

      {showClosing && (
        <ClosingOverlay onCancel={handleCloseCancel} onClose={handleCloseConfirm} />
      )}

      <div
        ref={ipodRef}
        className="w-full max-w-[480px] min-h-screen flex flex-col p-5 relative select-none"
        style={{ background: 'var(--ipod-body, #1a1a1a)' }}
      >
        {/* Close button */}
        <button
          onClick={handleClose}
          className="absolute top-3 right-3 z-50 w-8 h-8 rounded-full flex items-center justify-center text-white/50 hover:text-white/80 transition-colors"
          style={{ background: 'rgba(255,255,255,0.1)' }}
        >
          ✕
        </button>

        {/* Guical logo */}
        <div
          className="absolute bottom-6 left-6 text-sm italic tracking-wide pointer-events-none z-10 opacity-60"
          style={{
            fontFamily: "'Playfair Display', serif",
            color: isWhiteSkin ? '#aaa' : '#888',
            textShadow: isWhiteSkin
              ? '0 1px 0 rgba(255,255,255,0.8), 0 -1px 0 rgba(0,0,0,0.1)'
              : '0 1px 0 rgba(255,255,255,0.1), 0 -1px 0 rgba(0,0,0,0.5)'
          }}
        >
          Guical
        </div>

        {/* Screen Frame */}
        <div className="rounded-xl p-2.5 mb-5 flex-1 flex flex-col" style={{ background: '#333' }}>
          <div
            className="rounded-md flex-1 flex flex-col overflow-hidden relative"
            style={{ background: 'var(--ipod-screen, #000)' }}
          >
            {/* Status bar */}
            <div
              className="flex justify-between items-center px-3 py-1.5 text-xs"
              style={{
                color: 'var(--ipod-text, #fff)',
                background: 'rgba(128,128,128,0.1)',
                borderBottom: '1px solid rgba(128,128,128,0.2)'
              }}
            >
              <span className="font-bold">iPod</span>
              <div className="flex items-center gap-2.5">
                <span
                  className="transition-opacity duration-300"
                  style={{ opacity: engine.isPlaying ? 1 : 0 }}
                >
                  ▶
                </span>
                <span>{clock}</span>
              </div>
            </div>

            {/* Display area */}
            <div
              className="flex-1 relative"
              style={{ touchAction: 'pan-y' }}
              onTouchStart={handleTouchStart}
              onTouchEnd={handleTouchEnd}
              onMouseDown={handleMouseDown}
              onMouseUp={handleMouseUp}
            >
              {currentView === 0 && (
                <Visualizer
                  getFrequencyData={engine.getFrequencyData}
                  accentColor={accentColor}
                  isWhiteSkin={isWhiteSkin}
                />
              )}
              {currentView === 1 && (
                <Equalizer
                  getFrequencyData={engine.getFrequencyData}
                  accentColor={accentColor}
                />
              )}
              {currentView === 2 && (
                <NowPlaying
                  track={currentTrackData}
                  isPlaying={engine.isPlaying}
                  accentColor={accentColor}
                />
              )}
              {currentView === 3 && (
                <IpodMenu
                  onNowPlaying={() => showView(2)}
                  onImport={triggerImport}
                  onAddMore={triggerAddMore}
                  onSave={handleSavePlaylist}
                  onLoad={handleLoadPlaylist}
                  onToggleShuffle={engine.toggleShuffle}
                  onToggleRepeat={engine.toggleRepeat}
                  onShowPlaylist={() => showView(4)}
                  isShuffled={engine.isShuffled}
                  repeatMode={engine.repeatMode}
                  trackCount={engine.tracks.length}
                  saveStatus={saveStatus}
                  loadStatus={loadStatus}
                />
              )}
              {currentView === 4 && (
                <PlaylistView
                  tracks={engine.tracks}
                  currentTrack={engine.currentTrack}
                  onSelectTrack={handleSelectTrack}
                  accentColor={accentColor}
                />
              )}
            </div>

            {/* Mode dots */}
            <div className="flex justify-center gap-2.5 py-3">
              {[0, 1, 2, 3].map(i => (
                <div
                  key={i}
                  className="w-2.5 h-2.5 rounded-full cursor-pointer transition-colors"
                  style={{
                    background: i === (currentView > 3 ? 3 : currentView)
                      ? (accentColor || '#3b82f6')
                      : (isWhiteSkin ? '#bbb' : '#444')
                  }}
                  onClick={() => showView(i)}
                />
              ))}
            </div>

            {/* Progress bar */}
            <ProgressBar
              currentTime={engine.currentTime}
              duration={engine.duration}
              onSeek={engine.seek}
              accentColor={accentColor}
            />
          </div>
        </div>

        {/* Click Wheel */}
        <ClickWheel
          onMenu={() => showView(3)}
          onPrev={engine.prevTrack}
          onNext={engine.nextTrack}
          onPlayPause={handleTogglePlay}
          onCenter={nextView}
          onVolumeChange={engine.changeVolume}
          isPlaying={engine.isPlaying}
        />

        {/* Skin button */}
        <div
          className="absolute bottom-5 right-5 w-10 h-10 rounded-full flex items-center justify-center text-lg cursor-pointer z-50 text-white"
          style={{
            background: accentColor || '#3b82f6',
            border: '3px solid #fff',
            boxShadow: `0 0 15px ${accentColor || '#3b82f6'}`
          }}
          onClick={() => setSkinIdx(prev => (prev + 1) % SKINS.length)}
        >
          {SKINS[skinIdx].icon}
        </div>

        {/* Fullscreen button */}
        <div
          className="absolute bottom-5 right-20 w-10 h-10 rounded-full flex items-center justify-center text-lg cursor-pointer z-50"
          style={{
            background: 'rgba(255,255,255,0.1)',
            border: '2px solid rgba(255,255,255,0.3)'
          }}
          onClick={toggleFullscreen}
        >
          <span className="text-white/70 text-sm">{isFullscreen ? '⊘' : '⊕'}</span>
        </div>
      </div>
    </div>
  );
}