import React, { useState, useRef, useCallback } from 'react';

// Dynamically load jsmediatags for ID3 parsing
function loadJsmediatags() {
  return new Promise((resolve) => {
    if (window.jsmediatags) { resolve(window.jsmediatags); return; }
    const s = document.createElement('script');
    s.src = 'https://cdnjs.cloudflare.com/ajax/libs/jsmediatags/3.9.5/jsmediatags.min.js';
    s.onload = () => resolve(window.jsmediatags);
    s.onerror = () => resolve(null);
    document.head.appendChild(s);
  });
}

function readMetadata(file) {
  return new Promise(async (resolve) => {
    const lib = await loadJsmediatags();
    if (!lib) { resolve({}); return; }
    lib.read(file, {
      onSuccess: (tag) => {
        const t = tag.tags;
        let coverUrl = null;
        if (t.picture) {
          const { data, format } = t.picture;
          const bytes = new Uint8Array(data);
          const blob = new Blob([bytes], { type: format });
          coverUrl = URL.createObjectURL(blob);
        }
        resolve({
          title: t.title || null,
          artist: t.artist || null,
          album: t.album || null,
          year: t.year || null,
          lyrics: t.lyrics?.lyrics || t.USLT?.lyrics || null,
          coverUrl
        });
      },
      onError: () => resolve({})
    });
  });
}

export default function MusicExplorer({ onImport, onClose, accentColor }) {
  const [files, setFiles] = useState([]);
  const [scanning, setScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [selected, setSelected] = useState(new Set());
  const [search, setSearch] = useState('');
  const fileInputRef = useRef(null);
  const cancelRef = useRef(false);

  const handlePick = async (e) => {
    const picked = Array.from(e.target.files || []).filter(f =>
      /\.(mp3|m4a|wav|ogg|flac|aac|wma)$/i.test(f.name) || f.type.startsWith('audio/')
    );
    if (!picked.length) return;

    setScanning(true);
    setScanProgress(0);
    cancelRef.current = false;
    const results = [];

    for (let i = 0; i < picked.length; i++) {
      if (cancelRef.current) break;
      const f = picked[i];
      const meta = await readMetadata(f);
      const rawName = f.name.replace(/\.[^/.]+$/, '');
      const parts = rawName.split(' - ');
      results.push({
        file: f,
        name: meta.title || parts[1] || parts[0] || rawName,
        artist: meta.artist || parts[0] || 'Desconocido',
        album: meta.album || '',
        year: meta.year || '',
        lyrics: meta.lyrics || null,
        coverUrl: meta.coverUrl || null,
        url: URL.createObjectURL(f),
        track_id: Date.now().toString(36) + Math.random().toString(36).substr(2, 6)
      });
      setScanProgress(Math.round(((i + 1) / picked.length) * 100));
    }

    setFiles(results);
    setSelected(new Set(results.map(r => r.track_id)));
    setScanning(false);
  };

  const toggleSelect = (id) => {
    setSelected(prev => {
      const s = new Set(prev);
      s.has(id) ? s.delete(id) : s.add(id);
      return s;
    });
  };

  const selectAll = () => setSelected(new Set(files.map(f => f.track_id)));
  const selectNone = () => setSelected(new Set());

  const handleImport = (replace) => {
    const chosen = files.filter(f => selected.has(f.track_id));
    if (!chosen.length) return;
    onImport(chosen, replace);
    onClose();
  };

  const filtered = search.trim()
    ? files.filter(f =>
        f.name.toLowerCase().includes(search.toLowerCase()) ||
        f.artist.toLowerCase().includes(search.toLowerCase()) ||
        f.album.toLowerCase().includes(search.toLowerCase())
      )
    : files;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-black text-white" style={{ fontFamily: 'Inter, sans-serif' }}>
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/10"
        style={{ background: '#111', flexShrink: 0 }}>
        <div className="flex items-center gap-2">
          <span className="text-lg">🎵</span>
          <div>
            <div className="font-bold text-sm">Explorador de Música</div>
            {files.length > 0 && (
              <div className="text-xs text-white/50">{selected.size} de {files.length} seleccionadas</div>
            )}
          </div>
        </div>
        <button onClick={onClose} className="w-8 h-8 rounded-full flex items-center justify-center text-white/50 hover:text-white" style={{ background: 'rgba(255,255,255,0.08)' }}>
          ✕
        </button>
      </div>

      {/* Scanning progress */}
      {scanning && (
        <div className="px-4 py-3 border-b border-white/10" style={{ background: '#111', flexShrink: 0 }}>
          <div className="flex justify-between text-xs text-white/60 mb-1">
            <span>Leyendo metadatos... {scanProgress}%</span>
            <button onClick={() => { cancelRef.current = true; }} className="text-red-400 hover:text-red-300">Cancelar</button>
          </div>
          <div className="h-1.5 rounded-full overflow-hidden" style={{ background: '#333' }}>
            <div className="h-full rounded-full transition-all duration-200"
              style={{ width: `${scanProgress}%`, background: accentColor || '#3b82f6' }} />
          </div>
        </div>
      )}

      {/* No files yet */}
      {!scanning && files.length === 0 && (
        <div className="flex-1 flex flex-col items-center justify-center gap-6 px-8">
          <div className="text-6xl">📂</div>
          <div className="text-center">
            <p className="font-semibold text-lg mb-1">Explorar archivos de música</p>
            <p className="text-sm text-white/50">Selecciona uno o varios archivos de audio. Se leerán automáticamente los metadatos (portada, artista, álbum, letra).</p>
          </div>
          <button
            onClick={() => fileInputRef.current?.click()}
            className="px-8 py-3 rounded-full font-semibold text-white text-sm"
            style={{ background: accentColor || '#3b82f6' }}
          >
            📁 Abrir archivos
          </button>
          <p className="text-xs text-white/30 text-center">MP3 · M4A · WAV · OGG · FLAC · AAC</p>
        </div>
      )}

      {/* File list */}
      {!scanning && files.length > 0 && (
        <>
          {/* Search + actions */}
          <div className="px-3 py-2 border-b border-white/10 flex gap-2" style={{ background: '#0e0e0e', flexShrink: 0 }}>
            <div className="relative flex-1">
              <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs text-white/30">🔍</span>
              <input
                type="text"
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Filtrar..."
                className="w-full pl-7 pr-3 py-1.5 text-xs rounded-full outline-none text-white placeholder-white/30"
                style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.12)' }}
                onTouchStart={e => e.stopPropagation()}
              />
            </div>
            <button onClick={selectAll} className="text-xs px-2 py-1 rounded" style={{ color: accentColor }}>Todo</button>
            <button onClick={selectNone} className="text-xs px-2 py-1 rounded text-white/40">Ninguno</button>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="text-xs px-2 py-1 rounded text-white/40 hover:text-white"
            >
              +
            </button>
          </div>

          {/* Tracks */}
          <div className="flex-1 overflow-y-auto">
            {filtered.map((f) => {
              const isSelected = selected.has(f.track_id);
              return (
                <div
                  key={f.track_id}
                  className="flex items-center gap-3 px-3 py-2.5 border-b cursor-pointer transition-colors"
                  style={{
                    borderColor: 'rgba(255,255,255,0.06)',
                    background: isSelected ? 'rgba(255,255,255,0.05)' : 'transparent'
                  }}
                  onClick={() => toggleSelect(f.track_id)}
                >
                  {/* Cover */}
                  <div className="w-10 h-10 rounded-lg flex-shrink-0 overflow-hidden flex items-center justify-center"
                    style={{ background: '#222' }}>
                    {f.coverUrl
                      ? <img src={f.coverUrl} alt="" className="w-full h-full object-cover" />
                      : <span className="text-lg">🎵</span>
                    }
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-semibold truncate text-white">{f.name}</div>
                    <div className="text-xs truncate" style={{ color: '#888' }}>
                      {f.artist}{f.album ? ` · ${f.album}` : ''}{f.year ? ` · ${f.year}` : ''}
                    </div>
                    {f.lyrics && <div className="text-xs mt-0.5" style={{ color: accentColor, opacity: 0.7 }}>📝 Letra</div>}
                  </div>

                  {/* Checkbox */}
                  <div
                    className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 border-2 transition-all"
                    style={{
                      borderColor: isSelected ? (accentColor || '#3b82f6') : '#444',
                      background: isSelected ? (accentColor || '#3b82f6') : 'transparent'
                    }}
                  >
                    {isSelected && <span className="text-white text-xs">✓</span>}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Import buttons */}
          <div className="px-4 py-3 border-t border-white/10 flex gap-3" style={{ background: '#111', flexShrink: 0 }}>
            <button
              onClick={() => handleImport(true)}
              disabled={selected.size === 0}
              className="flex-1 py-2.5 rounded-full font-semibold text-sm text-white disabled:opacity-40"
              style={{ background: accentColor || '#3b82f6' }}
            >
              Importar ({selected.size})
            </button>
            <button
              onClick={() => handleImport(false)}
              disabled={selected.size === 0}
              className="flex-1 py-2.5 rounded-full font-semibold text-sm disabled:opacity-40"
              style={{ background: 'rgba(255,255,255,0.1)', color: '#fff' }}
            >
              ➕ Agregar
            </button>
          </div>
        </>
      )}

      <input
        ref={fileInputRef}
        type="file"
        accept="audio/*,.mp3,.m4a,.wav,.ogg,.flac,.aac"
        multiple
        className="hidden"
        onChange={handlePick}
      />
    </div>
  );
}