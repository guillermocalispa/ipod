import React from 'react';

export default function IpodMenu({
  onNowPlaying,
  onImport,
  onAddMore,
  onSave,
  onLoad,
  onToggleShuffle,
  onToggleRepeat,
  onShowPlaylist,
  isShuffled,
  repeatMode,
  trackCount,
  saveStatus,
  loadStatus
}) {
  const repeatTexts = ['OFF', 'ALL', 'ONE'];

  return (
    <div
      className="absolute inset-0 overflow-y-auto"
      style={{ background: 'var(--ipod-menu-bg, #fff)' }}
    >
      <div
        className="px-4 py-2.5 text-xs font-bold uppercase"
        style={{
          color: '#888',
          background: 'rgba(128,128,128,0.1)',
          borderBottom: '1px solid var(--ipod-menu-border, #eee)'
        }}
      >
        Menú Principal
      </div>

      <MenuItem icon="♪" label="Ahora sonando" onClick={onNowPlaying} />
      <MenuItem icon="📁" label="Importar música" onClick={onImport} />
      <MenuItem icon="➕" label="Agregar más archivos" onClick={onAddMore} status="Añadir" />
      <MenuItem icon="💾" label="Guardar playlist" onClick={onSave} status={saveStatus} />
      <MenuItem icon="📂" label="Cargar playlist" onClick={onLoad} status={loadStatus} />
      <MenuItem
        icon="🔀"
        label="Aleatorio"
        onClick={onToggleShuffle}
        status={isShuffled ? 'ON' : 'OFF'}
        active={isShuffled}
      />
      <MenuItem
        icon="🔁"
        label="Repetir"
        onClick={onToggleRepeat}
        status={repeatTexts[repeatMode]}
        active={repeatMode > 0}
      />
      <MenuItem
        icon="📋"
        label="Ver playlist"
        onClick={onShowPlaylist}
        status={String(trackCount)}
      />
    </div>
  );
}

function MenuItem({ icon, label, onClick, status, active, arrow = true }) {
  return (
    <div
      className="flex justify-between items-center px-4 py-3 cursor-pointer transition-colors duration-150 hover:text-white"
      style={{
        borderBottom: '1px solid var(--ipod-menu-border, #eee)',
        color: 'var(--ipod-menu-text, #333)',
      }}
      onClick={onClick}
      onMouseEnter={e => {
        e.currentTarget.style.background = 'var(--ipod-accent, #3b82f6)';
        e.currentTarget.style.color = '#fff';
      }}
      onMouseLeave={e => {
        e.currentTarget.style.background = 'transparent';
        e.currentTarget.style.color = 'var(--ipod-menu-text, #333)';
      }}
    >
      <span className="text-sm">{icon} {label}</span>
      <div className="flex items-center gap-2">
        {status && (
          <span
            className="text-xs"
            style={{ color: active ? 'var(--ipod-accent, #3b82f6)' : '#999' }}
          >
            {status}
          </span>
        )}
        {arrow && <span className="text-xs" style={{ color: '#999' }}>▶</span>}
      </div>
    </div>
  );
}