import React from 'react';

function fmt(s) {
  if (!s || isNaN(s)) return '0:00';
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60).toString().padStart(2, '0');
  return m + ':' + sec;
}

export default function ProgressBar({ currentTime, duration, onSeek, accentColor }) {
  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  const handleClick = (e) => {
    const r = e.currentTarget.getBoundingClientRect();
    const fraction = (e.clientX - r.left) / r.width;
    onSeek(Math.max(0, Math.min(1, fraction)));
  };

  return (
    <div className="px-4 py-3" style={{ background: 'rgba(128,128,128,0.05)' }}>
      <div
        className="h-1.5 rounded-full cursor-pointer relative"
        style={{ background: '#333' }}
        onClick={handleClick}
      >
        <div
          className="h-full rounded-full transition-all duration-100"
          style={{
            width: `${progress}%`,
            background: accentColor || '#3b82f6'
          }}
        />
      </div>
      <div className="flex justify-between mt-1.5 text-xs" style={{ color: '#666' }}>
        <span>{fmt(currentTime)}</span>
        <span>{fmt(duration)}</span>
      </div>
    </div>
  );
}