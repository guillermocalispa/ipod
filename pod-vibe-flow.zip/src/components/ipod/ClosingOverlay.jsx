import React, { useState, useEffect, useRef } from 'react';

export default function ClosingOverlay({ onCancel, onClose }) {
  const [timeLeft, setTimeLeft] = useState(3);
  const timerRef = useRef(null);
  const closedRef = useRef(false);

  useEffect(() => {
    timerRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timerRef.current);
          if (!closedRef.current) {
            closedRef.current = true;
            onClose();
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timerRef.current);
  }, [onClose]);

  const handleCancel = () => {
    clearInterval(timerRef.current);
    onCancel();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm">
      <div className="text-center">
        <div className="text-6xl mb-6">⏸</div>
        <p className="text-white text-lg font-semibold mb-2">Cerrando reproductor...</p>
        <p className="text-white/60 text-sm mb-8">
          Cerrando en {timeLeft} segundo{timeLeft !== 1 ? 's' : ''}
        </p>

        {/* Progress bar countdown */}
        <div className="w-48 mx-auto h-1 bg-white/20 rounded-full overflow-hidden mb-6">
          <div
            className="h-full bg-blue-500 rounded-full transition-all duration-1000 ease-linear"
            style={{ width: `${(timeLeft / 3) * 100}%` }}
          />
        </div>

        <button
          onClick={handleCancel}
          className="px-6 py-2 bg-white/10 hover:bg-white/20 text-white rounded-full text-sm transition-colors"
        >
          Cancelar
        </button>
      </div>
    </div>
  );
}