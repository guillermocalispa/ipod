import React, { useEffect, useRef, useState } from 'react';

const NUM_BANDS = 16;
const NUM_SEGMENTS = 20;

const MODES = ['rgb', 'fire', 'ice', 'neon', 'gold'];

function getSegmentColor(s, total, mode) {
  const r = s / total;
  switch (mode) {
    case 'fire':
      if (r < 0.4) return '#ff4400';
      if (r < 0.7) return '#ff8800';
      if (r < 0.88) return '#ffdd00';
      return '#ffffff';
    case 'ice':
      if (r < 0.5) return '#0088ff';
      if (r < 0.75) return '#00ddff';
      if (r < 0.9) return '#aaeeff';
      return '#ffffff';
    case 'neon':
      if (r < 0.33) return '#ff00ff';
      if (r < 0.66) return '#00ffff';
      if (r < 0.88) return '#ff00aa';
      return '#ffffff';
    case 'gold':
      if (r < 0.5) return '#aa6600';
      if (r < 0.75) return '#ffaa00';
      if (r < 0.9) return '#ffee44';
      return '#ffffff';
    case 'rgb':
    default:
      if (r < 0.5) return '#00ff00';
      if (r < 0.7) return '#00ffff';
      if (r < 0.82) return '#ffff00';
      if (r < 0.92) return '#ff8800';
      return '#ff0000';
  }
}

export default function Equalizer({ getFrequencyData }) {
  const [modeIdx, setModeIdx] = useState(0);
  const [levels, setLevels] = useState(Array(NUM_BANDS).fill(0));
  const [peaks, setPeaks] = useState(Array(NUM_BANDS).fill(0));
  const peaksRef = useRef(Array(NUM_BANDS).fill(0));
  const peakVelRef = useRef(Array(NUM_BANDS).fill(0));
  const animRef = useRef(null);
  const modeRef = useRef(MODES[0]);

  const handleTap = () => {
    const next = (modeIdx + 1) % MODES.length;
    setModeIdx(next);
    modeRef.current = MODES[next];
  };

  useEffect(() => {
    const tick = () => {
      animRef.current = requestAnimationFrame(tick);
      const data = getFrequencyData();
      const newLevels = [];
      const newPeaks = [];

      for (let b = 0; b < NUM_BANDS; b++) {
        let value = 0;
        if (data) {
          const start = Math.floor((b / NUM_BANDS) * data.length * 0.75);
          const end = Math.floor(((b + 1) / NUM_BANDS) * data.length * 0.75);
          let sum = 0;
          for (let i = start; i < end; i++) sum += data[i] || 0;
          value = end > start ? sum / (end - start) : 0;
        }
        const filled = Math.round((value / 255) * NUM_SEGMENTS);
        newLevels.push(filled);

        if (filled >= peaksRef.current[b]) {
          peaksRef.current[b] = filled;
          peakVelRef.current[b] = 0;
        } else {
          peakVelRef.current[b] += 0.15;
          peaksRef.current[b] = Math.max(0, peaksRef.current[b] - peakVelRef.current[b]);
        }
        newPeaks.push(Math.round(peaksRef.current[b]));
      }

      setLevels(newLevels);
      setPeaks(newPeaks);
    };

    tick();
    return () => cancelAnimationFrame(animRef.current);
  }, [getFrequencyData]);

  const mode = MODES[modeIdx];

  return (
    <div
      className="absolute inset-0 flex flex-col"
      style={{ background: '#000', cursor: 'pointer', userSelect: 'none' }}
      onClick={handleTap}
    >
      {/* Bands */}
      <div className="flex-1 flex items-end px-1 pb-1 gap-0.5">
        {Array.from({ length: NUM_BANDS }).map((_, b) => (
          <div key={b} className="flex-1 flex flex-col-reverse gap-px" style={{ height: '100%' }}>
            {Array.from({ length: NUM_SEGMENTS }).map((_, s) => {
              const isLit = s < levels[b];
              const isPeak = peaks[b] === s && s > 0;
              const color = getSegmentColor(s, NUM_SEGMENTS, mode);
              return (
                <div
                  key={s}
                  style={{
                    width: '100%',
                    height: '3px',
                    marginBottom: '3px',
                    borderRadius: '1px',
                    background: isLit
                      ? color
                      : isPeak
                      ? '#ffffff'
                      : 'rgba(255,255,255,0.05)',
                    boxShadow: isLit
                      ? `0 0 4px ${color}`
                      : isPeak
                      ? '0 0 6px #fff'
                      : 'none'
                  }}
                />
              );
            })}
          </div>
        ))}
      </div>

      {/* Mode label */}
      <div
        className="text-right pr-2 pb-1 text-xs font-mono pointer-events-none"
        style={{ color: 'rgba(255,255,255,0.3)', fontSize: 9 }}
      >
        {mode.toUpperCase()} · toca para cambiar
      </div>
    </div>
  );
}