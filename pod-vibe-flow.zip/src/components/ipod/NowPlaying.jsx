import React, { useState } from 'react';

export default function NowPlaying({ track, isPlaying, accentColor }) {
  const [showLyrics, setShowLyrics] = useState(false);

  if (showLyrics && track?.lyrics) {
    return (
      <div className="absolute inset-0 flex flex-col" style={{ background: 'var(--ipod-screen, #000)' }}>
        <div
          className="flex items-center justify-between px-3 py-2 text-xs cursor-pointer"
          style={{ borderBottom: '1px solid rgba(128,128,128,0.2)', color: 'var(--ipod-text, #fff)' }}
          onClick={() => setShowLyrics(false)}
        >
          <span style={{ color: accentColor }}>◀ Volver</span>
          <span className="font-semibold">Letra</span>
          <span></span>
        </div>
        <div className="flex-1 overflow-y-auto px-4 py-3">
          <pre
            className="text-xs whitespace-pre-wrap leading-relaxed"
            style={{ color: 'var(--ipod-text, #fff)', fontFamily: 'Inter, sans-serif', opacity: 0.85 }}
          >
            {track.lyrics}
          </pre>
        </div>
      </div>
    );
  }

  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center text-center gap-4 px-4">
      {/* Cover art or disc */}
      {track?.coverUrl ? (
        <div className="w-36 h-36 rounded-xl overflow-hidden shadow-2xl"
          style={{
            animation: isPlaying ? 'ipod-spin 8s linear infinite' : 'none',
            borderRadius: '50%'
          }}>
          <img src={track.coverUrl} alt="cover" className="w-full h-full object-cover" />
        </div>
      ) : (
        <div
          className="w-36 h-36 rounded-full flex items-center justify-center text-5xl"
          style={{
            background: 'linear-gradient(135deg, #444 0%, #111 50%, #444 100%)',
            animation: isPlaying ? 'ipod-spin 3s linear infinite' : 'none'
          }}
        >
          <span style={{ color: '#555' }}>♪</span>
        </div>
      )}

      {/* Track info */}
      <div className="w-full">
        <div className="text-base font-bold truncate" style={{ color: 'var(--ipod-text, #fff)' }}>
          {track?.name || 'Sin pista'}
        </div>
        <div className="text-sm mt-0.5" style={{ color: accentColor || '#3b82f6' }}>
          {track?.artist || 'Desliza o toca MENU'}
        </div>
        {track?.album && (
          <div className="text-xs mt-0.5 opacity-50" style={{ color: 'var(--ipod-text, #fff)' }}>
            {track.album}{track.year ? ` · ${track.year}` : ''}
          </div>
        )}
      </div>

      {/* Lyrics button */}
      {track?.lyrics && (
        <button
          onClick={() => setShowLyrics(true)}
          className="text-xs px-3 py-1 rounded-full"
          style={{ background: `${accentColor}22`, color: accentColor, border: `1px solid ${accentColor}44` }}
        >
          📝 Ver letra
        </button>
      )}
    </div>
  );
}