import React, { useRef, useEffect } from 'react';

export default function Visualizer({ getFrequencyData, accentColor, isWhiteSkin }) {
  const canvasRef = useRef(null);
  const animRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    const resize = () => {
      const r = canvas.parentElement.getBoundingClientRect();
      canvas.width = r.width;
      canvas.height = r.height;
    };
    resize();
    window.addEventListener('resize', resize);

    const animate = () => {
      animRef.current = requestAnimationFrame(animate);
      const data = getFrequencyData();

      ctx.fillStyle = isWhiteSkin ? '#fff' : '#000';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      if (!data) return;

      const accent = accentColor || '#3b82f6';

      // Wave
      ctx.beginPath();
      ctx.moveTo(0, canvas.height / 2);
      for (let i = 0; i < canvas.width; i += 2) {
        const ix = Math.floor((i / canvas.width) * data.length);
        const v = data[ix] || 0;
        const y = (canvas.height / 2) - (v / 255) * (canvas.height / 2.5);
        ctx.lineTo(i, y);
      }
      ctx.strokeStyle = accent;
      ctx.lineWidth = 3;
      ctx.stroke();

      // Bars
      const bw = canvas.width / 24;
      for (let i = 0; i < 24; i++) {
        const v = data[i * 2] || 0;
        const h = (v / 255) * (canvas.height / 2);
        ctx.fillStyle = accent;
        ctx.globalAlpha = 0.3;
        ctx.fillRect(i * bw, canvas.height - h, bw - 2, h);
        ctx.globalAlpha = 1;
      }
    };

    animate();

    return () => {
      cancelAnimationFrame(animRef.current);
      window.removeEventListener('resize', resize);
    };
  }, [getFrequencyData, accentColor, isWhiteSkin]);

  return (
    <div className="absolute inset-0 p-3">
      <canvas ref={canvasRef} className="w-full h-full rounded" />
    </div>
  );
}