import React, { useState, useMemo, useRef, useCallback } from 'react';

function highlight(text, query) {
  if (!query) return text;
  const idx = text.toLowerCase().indexOf(query.toLowerCase());
  if (idx === -1) return text;
  return (
    <>
      {text.slice(0, idx)}
      <mark style={{ background: 'var(--ipod-accent, #3b82f6)', color: '#fff', borderRadius: 2 }}>
        {text.slice(idx, idx + query.length)}
      </mark>
      {text.slice(idx + query.length)}
    </>
  );
}

export default function PlaylistView({ tracks, currentTrack, onSelectTrack, accentColor }) {
  const [query, setQuery] = useState('');
  const inputRef = useRef(null);

  // Debounced search for large libraries
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const debounceRef = useRef(null);

  const handleSearch = useCallback((e) => {
    const val = e.target.value;
    setQuery(val);
    clearTimeout(debounceRef.current);
    // For large lists (>200 tracks) debounce 150ms, otherwise instant
    const delay = tracks.length > 200 ? 150 : 0;
    debounceRef.current = setTimeout(() => setDebouncedQuery(val), delay);
  }, [tracks.length]);

  const filtered = useMemo(() => {
    if (!debouncedQuery.trim()) return tracks.map((t, i) => ({ ...t, originalIndex: i }));
    const q = debouncedQuery.toLowerCase();
    return tracks
      .map((t, i) => ({ ...t, originalIndex: i }))
      .filter(t =>
        t.name.toLowerCase().includes(q) ||
        (t.artist && t.artist.toLowerCase().includes(q))
      );
  }, [tracks, debouncedQuery]);

  return (
    <div
      className="absolute inset-0 flex flex-col"
      style={{ background: 'var(--ipod-menu-bg, #fff)' }}
    >
      {/* Header */}
      <div
        className="px-4 py-2 text-xs font-bold uppercase flex-shrink-0"
        style={{
          color: '#888',
          background: 'rgba(128,128,128,0.1)',
          borderBottom: '1px solid var(--ipod-menu-border, #eee)'
        }}
      >
        Playlist — {debouncedQuery ? `${filtered.length} de ${tracks.length}` : `${tracks.length} canciones`}
      </div>

      {/* Search bar */}
      <div
        className="px-3 py-2 flex-shrink-0"
        style={{ borderBottom: '1px solid var(--ipod-menu-border, #eee)' }}
      >
        <div className="relative">
          <span
            className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs pointer-events-none"
            style={{ color: '#999' }}
          >
            🔍
          </span>
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={handleSearch}
            placeholder="Buscar canción o artista..."
            className="w-full pl-7 pr-8 py-1.5 text-xs rounded-full outline-none"
            style={{
              background: 'rgba(128,128,128,0.12)',
              color: 'var(--ipod-menu-text, #333)',
              border: `1px solid ${query ? (accentColor || '#3b82f6') : 'rgba(128,128,128,0.2)'}`,
              transition: 'border-color 0.2s'
            }}
            // Prevent swipe from firing while typing
            onMouseDown={e => e.stopPropagation()}
            onTouchStart={e => e.stopPropagation()}
          />
          {query && (
            <button
              className="absolute right-2 top-1/2 -translate-y-1/2 text-xs w-4 h-4 rounded-full flex items-center justify-center"
              style={{ color: '#999' }}
              onClick={() => { setQuery(''); setDebouncedQuery(''); inputRef.current?.focus(); }}
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* Track list */}
      <div className="flex-1 overflow-y-auto">
        {tracks.length === 0 && (
          <div className="px-4 py-8 text-center text-sm" style={{ color: '#999' }}>
            No hay canciones. Usa MENU para importar.
          </div>
        )}

        {tracks.length > 0 && filtered.length === 0 && (
          <div className="px-4 py-8 text-center text-sm" style={{ color: '#999' }}>
            Sin resultados para "{query}"
          </div>
        )}

        {filtered.map((t) => {
          const i = t.originalIndex;
          const isActive = i === currentTrack;
          return (
            <div
              key={t.track_id || i}
              className="flex items-center px-4 py-2.5 cursor-pointer transition-colors duration-100"
              style={{
                borderBottom: '1px solid var(--ipod-menu-border, #eee)',
                color: isActive ? '#fff' : 'var(--ipod-menu-text, #333)',
                background: isActive ? (accentColor || '#3b82f6') : 'transparent'
              }}
              onClick={() => onSelectTrack(i)}
              onMouseEnter={e => {
                if (!isActive) {
                  e.currentTarget.style.background = accentColor || '#3b82f6';
                  e.currentTarget.style.color = '#fff';
                }
              }}
              onMouseLeave={e => {
                if (!isActive) {
                  e.currentTarget.style.background = 'transparent';
                  e.currentTarget.style.color = 'var(--ipod-menu-text, #333)';
                }
              }}
            >
              {/* Track number */}
              <span
                className="text-xs w-7 flex-shrink-0 font-mono"
                style={{ color: isActive ? 'rgba(255,255,255,0.7)' : '#bbb' }}
              >
                {isActive ? '▶' : i + 1}
              </span>

              {/* Name + artist */}
              <div className="flex-1 min-w-0">
                <div className="text-xs font-semibold truncate leading-tight">
                  {highlight(t.name, debouncedQuery)}
                </div>
                {t.artist && t.artist !== 'Desconocido' && (
                  <div
                    className="text-xs truncate leading-tight mt-0.5"
                    style={{ color: isActive ? 'rgba(255,255,255,0.75)' : '#999' }}
                  >
                    {highlight(t.artist, debouncedQuery)}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}