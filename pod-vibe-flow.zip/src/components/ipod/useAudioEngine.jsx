import { useState, useRef, useCallback, useEffect } from 'react';

export default function useAudioEngine() {
  const audioRef = useRef(null);
  const audioCtxRef = useRef(null);
  const analyserRef = useRef(null);
  const dataArrayRef = useRef(null);
  const sourceRef = useRef(null);

  const [tracks, setTracks] = useState([]);
  const [currentTrack, setCurrentTrack] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isShuffled, setIsShuffled] = useState(false);
  const [repeatMode, setRepeatMode] = useState(0); // 0=off, 1=all, 2=one
  const [volume, setVolume] = useState(0.7);

  // Initialize audio element
  useEffect(() => {
    const audio = new Audio();
    audio.crossOrigin = 'anonymous';
    audio.volume = 0.7;
    audioRef.current = audio;

    audio.addEventListener('timeupdate', () => {
      setCurrentTime(audio.currentTime);
    });

    audio.addEventListener('loadedmetadata', () => {
      setDuration(audio.duration);
    });

    audio.addEventListener('ended', () => {
      // Will be handled by the effect below
    });

    return () => {
      audio.pause();
      audio.src = '';
    };
  }, []);

  // Handle track end
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleEnded = () => {
      if (repeatMode === 2) {
        audio.currentTime = 0;
        audio.play();
      } else if (tracks.length > 0) {
        const nextIdx = isShuffled
          ? Math.floor(Math.random() * tracks.length)
          : (currentTrack + 1) % tracks.length;
        loadTrack(nextIdx);
      }
    };

    audio.addEventListener('ended', handleEnded);
    return () => audio.removeEventListener('ended', handleEnded);
  }, [repeatMode, isShuffled, currentTrack, tracks.length]);

  const initAudioContext = useCallback(() => {
    if (!audioCtxRef.current && audioRef.current) {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 128;

      const source = ctx.createMediaElementSource(audioRef.current);
      source.connect(analyser);
      analyser.connect(ctx.destination);

      audioCtxRef.current = ctx;
      analyserRef.current = analyser;
      sourceRef.current = source;
      dataArrayRef.current = new Uint8Array(analyser.frequencyBinCount);
    }
    if (audioCtxRef.current?.state === 'suspended') {
      audioCtxRef.current.resume();
    }
  }, []);

  const loadTrack = useCallback((idx) => {
    if (idx < 0 || idx >= tracks.length) return;
    const audio = audioRef.current;
    if (!audio) return;

    setCurrentTrack(idx);
    audio.src = tracks[idx].url;
    audio.play();
    setIsPlaying(true);
    initAudioContext();
  }, [tracks, initAudioContext]);

  const togglePlay = useCallback(() => {
    const audio = audioRef.current;
    if (!audio || tracks.length === 0) return false;

    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio.play();
      setIsPlaying(true);
      initAudioContext();
    }
    return true;
  }, [isPlaying, tracks.length, initAudioContext]);

  const pauseAudio = useCallback(() => {
    const audio = audioRef.current;
    if (audio && isPlaying) {
      audio.pause();
      setIsPlaying(false);
    }
  }, [isPlaying]);

  const prevTrack = useCallback(() => {
    const audio = audioRef.current;
    if (!audio || tracks.length === 0) return;
    if (audio.currentTime > 3) {
      audio.currentTime = 0;
    } else {
      const idx = (currentTrack - 1 + tracks.length) % tracks.length;
      loadTrack(idx);
    }
  }, [currentTrack, tracks.length, loadTrack]);

  const nextTrack = useCallback(() => {
    if (tracks.length === 0) return;
    const idx = isShuffled
      ? Math.floor(Math.random() * tracks.length)
      : (currentTrack + 1) % tracks.length;
    loadTrack(idx);
  }, [currentTrack, tracks.length, isShuffled, loadTrack]);

  const seek = useCallback((fraction) => {
    const audio = audioRef.current;
    if (!audio || !audio.duration) return;
    audio.currentTime = fraction * audio.duration;
  }, []);

  const changeVolume = useCallback((delta) => {
    setVolume(prev => {
      const newVol = Math.max(0, Math.min(1, prev + delta));
      if (audioRef.current) audioRef.current.volume = newVol;
      return newVol;
    });
  }, []);

  // Add pre-parsed track objects (from MusicExplorer with metadata)
  const addParsedTracks = useCallback((parsedTracks, replace = false) => {
    if (!parsedTracks.length) return 0;
    if (replace) {
      setTracks(parsedTracks);
      setTimeout(() => loadTrack(0), 100);
    } else {
      setTracks(prev => [...prev, ...parsedTracks]);
    }
    return parsedTracks.length;
  }, [loadTrack]);

  const addTracks = useCallback((files, replace = false) => {
    const audioFiles = Array.from(files).filter(f => {
      const n = f.name.toLowerCase();
      return n.endsWith('.mp3') || n.endsWith('.m4a') || n.endsWith('.wav') || n.endsWith('.ogg') || n.endsWith('.flac') || f.type.startsWith('audio/');
    });

    if (audioFiles.length === 0) return 0;

    const newTracks = audioFiles.map(f => {
      const name = f.name.replace(/\.[^/.]+$/, '');
      const parts = name.split(' - ');
      return {
        name: parts[1] || name,
        artist: parts[0] || 'Desconocido',
        url: URL.createObjectURL(f),
        duration: 0,
        track_id: Date.now().toString() + Math.random().toString(36).substr(2, 9)
      };
    });

    if (replace) {
      setTracks(newTracks);
      if (newTracks.length > 0) {
        setTimeout(() => loadTrack(0), 100);
      }
    } else {
      setTracks(prev => [...prev, ...newTracks]);
    }

    return newTracks.length;
  }, [loadTrack]);

  const getFrequencyData = useCallback(() => {
    if (!analyserRef.current || !dataArrayRef.current) return null;
    analyserRef.current.getByteFrequencyData(dataArrayRef.current);
    return dataArrayRef.current;
  }, []);

  const toggleShuffle = useCallback(() => {
    setIsShuffled(prev => !prev);
  }, []);

  const toggleRepeat = useCallback(() => {
    setRepeatMode(prev => (prev + 1) % 3);
  }, []);

  return {
    tracks,
    setTracks,
    addParsedTracks,
    currentTrack,
    isPlaying,
    currentTime,
    duration,
    isShuffled,
    repeatMode,
    volume,
    loadTrack,
    togglePlay,
    pauseAudio,
    prevTrack,
    nextTrack,
    seek,
    changeVolume,
    addTracks,
    getFrequencyData,
    toggleShuffle,
    toggleRepeat
  };
}