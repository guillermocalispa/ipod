import React, { useRef } from 'react';

export default function ClickWheel({
  onMenu,
  onPrev,
  onNext,
  onPlayPause,
  onCenter,
  onVolumeChange,
  isPlaying
}) {
  const lastYRef = useRef(0);
  const draggingRef = useRef(false);

  const handleTouchStart = (e) => {
    if (e.target.closest('[data-wheel-btn]') || e.target.closest('[data-wheel-center]')) return;
    lastYRef.current = e.touches[0].clientY;
    draggingRef.current = true;
  };

  const handleTouchMove = (e) => {
    if (!draggingRef.current) return;
    if (e.target.closest('[data-wheel-btn]') || e.target.closest('[data-wheel-center]')) return;
    const dy = lastYRef.current - e.touches[0].clientY;
    onVolumeChange(dy * 0.01);
    lastYRef.current = e.touches[0].clientY;
  };

  const handleTouchEnd = () => {
    draggingRef.current = false;
  };

  return (
    <div className="flex flex-col items-center gap-4">
      {/* Wheel */}
      <div
        className="relative rounded-full"
        style={{
          width: 220,
          height: 220,
          background: 'var(--ipod-wheel, #2a2a2a)',
          boxShadow: '0 5px 15px rgba(0,0,0,0.3)'
        }}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* MENU */}
        <div
          data-wheel-btn
          className="absolute top-1 left-1/2 -translate-x-1/2 p-4 text-xs font-semibold cursor-pointer select-none active:opacity-70"
          style={{ color: '#888' }}
          onClick={onMenu}
        >
          MENU
        </div>

        {/* Prev */}
        <div
          data-wheel-btn
          className="absolute left-1 top-1/2 -translate-y-1/2 p-4 text-base cursor-pointer select-none active:opacity-70"
          style={{ color: '#888' }}
          onClick={onPrev}
        >
          ⏮
        </div>

        {/* Next */}
        <div
          data-wheel-btn
          className="absolute right-1 top-1/2 -translate-y-1/2 p-4 text-base cursor-pointer select-none active:opacity-70"
          style={{ color: '#888' }}
          onClick={onNext}
        >
          ⏭
        </div>

        {/* Play/Pause */}
        <div
          data-wheel-btn
          className="absolute bottom-1 left-1/2 -translate-x-1/2 p-4 text-sm cursor-pointer select-none active:opacity-70"
          style={{ color: '#888' }}
          onClick={onPlayPause}
        >
          {isPlaying ? '⏸' : '▶'}
        </div>

        {/* Center button */}
        <div
          data-wheel-center
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 rounded-full cursor-pointer active:scale-95 transition-transform"
          style={{
            background: 'linear-gradient(145deg, #3a3a3a, #222)',
            border: '2px solid #444'
          }}
          onClick={onCenter}
        />
      </div>

      {/* Bottom buttons */}
      <div className="flex gap-5">
        <button
          className="w-14 h-8 rounded-full flex items-center justify-center text-sm cursor-pointer border"
          style={{
            background: 'var(--ipod-btn, #333)',
            borderColor: '#555',
            color: '#777'
          }}
          onClick={onPlayPause}
        >
          {isPlaying ? '⏸' : '▶'}
        </button>
      </div>
    </div>
  );
}